"""临时脚本：探测 dashscope embedding 响应结构。"""
import os
import sys
sys.path.insert(0, r"d:\localModel\enterprise_ai\backend")

import dashscope
from app.config import settings

resp = dashscope.TextEmbedding.call(
    model=settings.EMBEDDING_MODEL,
    input=["hello world", "前端组件"],
    api_key=settings.DASHSCOPE_API_KEY,
    dimension=1024,
)
print("status:", resp.status_code)
print("output keys:", list(resp.output.keys()) if hasattr(resp.output, "keys") else type(resp.output))
embs = resp.output["embeddings"]
print("emb item keys:", list(embs[0].keys()))
print("usage:", resp.usage)
print("first emb dim:", len(embs[0]["embedding"]))
