"""临时脚本：回归验证 chat usage 落库 + 报表。"""
import json

import requests

BASE = "http://127.0.0.1:8003"

r = requests.post(
    f"{BASE}/api/chat/stream",
    json={"question": "el-table 如何开启斑马纹和边框？", "doc_ids": [3], "mode": "qa"},
    stream=True, timeout=300,
)
ev = None
usage = None
n_delta = 0
for raw in r.iter_lines(chunk_size=1, decode_unicode=True):
    if not raw or raw.startswith(":"):
        continue
    if raw.startswith("event:"):
        ev = raw[6:].strip()
        continue
    if raw.startswith("data:") and ev:
        body = raw[5:].strip()
        try:
            data = json.loads(body)
        except Exception:
            continue
        if ev == "delta":
            n_delta += 1
        elif ev == "done":
            usage = data.get("usage")
        elif ev == "error":
            print("[error]", data)
            raise SystemExit(1)

print(f"deltas={n_delta}")
print("usage:", json.dumps(usage, ensure_ascii=False))

s = requests.get(f"{BASE}/api/chat/usage/summary", timeout=30).json()
print(json.dumps(s, ensure_ascii=False, indent=1))
assert s["today"]["calls"] >= 2, f"chat usage missing: {s}"
assert usage and usage.get("completion_tokens", 0) > 0, "usage empty"
print("\n[PASS] chat usage 落库并计入报表")
