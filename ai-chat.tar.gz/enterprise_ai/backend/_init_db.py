import pymysql

conn = pymysql.connect(host="127.0.0.1", port=3306, user="root", password="sunbo.0208")
cur = conn.cursor()
cur.execute(
    "CREATE DATABASE IF NOT EXISTS enterprise_ai "
    "DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
)
conn.commit()
cur.execute("SHOW DATABASES LIKE 'enterprise_ai'")
print("enterprise_ai DB:", cur.fetchall())
conn.close()
