"""临时脚本：端到端测试企业级 AI 应用。"""
import json

import requests

BASE = "http://127.0.0.1:8003"

# 1) 上传样例组件文档
print("=== 1) 上传文档 ===")
with open(r"d:\localModel\enterprise_ai\sample_docs\elementplus_table.md", "rb") as f:
    r = requests.post(
        f"{BASE}/api/docs/upload",
        files={"file": ("elementplus_table.md", f, "text/markdown")},
        timeout=300,
    )
print(r.status_code, json.dumps(r.json(), ensure_ascii=False))
doc_id = r.json()["id"]

# 2) 文档列表
print("\n=== 2) 文档列表 ===")
r = requests.get(f"{BASE}/api/docs", timeout=30)
print(json.dumps(r.json(), ensure_ascii=False, indent=1))

# 3) 流式答疑（RAG + usage）
print("\n=== 3) 流式问答 ===")
r = requests.post(
    f"{BASE}/api/chat/stream",
    json={
        "question": "el-table 怎么自定义列内容？给我一个完整示例",
        "doc_ids": [doc_id],
        "mode": "code",
    },
    stream=True,
    timeout=300,
)
ev = None
cites = None
answer = []
usage = None
for raw in r.iter_lines(chunk_size=1, decode_unicode=True):
    if not raw or raw.startswith(":"):
        continue
    if raw.startswith("event:"):
        ev = raw[6:].strip()
        continue
    if raw.startswith("data:") and ev:
        body = raw[5:].strip()
        try:
            data = json.loads(body)
        except Exception:
            continue
        if ev == "meta":
            print(f"[meta] conv={data['conversation_id']}")
        elif ev == "cite":
            cites = data
            print(f"[cite] {len(data)} 片段: {[(c['doc_name'], c['score']) for c in data]}")
        elif ev == "delta":
            answer.append(data["content"])
        elif ev == "done":
            usage = data["usage"]
            print(f"[done] content_len={len(data['content'])}")
        elif ev in ("error",):
            print(f"[error] {data}")

full = "".join(answer)
print(f"\n回答长度: {len(full)} 字")
print("前 400 字:", full[:400])
print("\nusage:", json.dumps(usage, ensure_ascii=False))

# 4) 成本面板
print("\n=== 4) 成本汇总 ===")
r = requests.get(f"{BASE}/api/chat/usage/summary", timeout=30)
s = r.json()
print(json.dumps(s, ensure_ascii=False, indent=1))

assert cites and usage and len(full) > 100, "链路不完整"
print("\n[OK] 全链路验证通过：上传→向量化→检索→生成→计量→报表")
